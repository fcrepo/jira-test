package fedora.services.oaiprovider;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import proai.SetInfo;
import proai.error.RepositoryException;
import fedora.client.FedoraClient;
import fedora.server.types.gen.MIMETypedStream;
import fedora.server.types.gen.ObjectFields;

/**
 * Because ResultCombiner doesn't implement an interface and CombinerRecordIterator doesn't use that
 * interface, the only way we can reuse CombinerRecordIterator is by extending ResultCombiner and
 * overriding all of its public methods, which we do in this class.
 * 
 * This class doesn't really combine anything. FedoraSearchCSVSource would be a better name, but this
 * name makes it more obvious that we're in some way related to ResultCombiner.
 * @author fransflippo
 *
 */
public class FedoraSearchResultCombiner extends ResultCombiner {

    private static final Logger logger = LoggerFactory.getLogger(FedoraSearchResultCombiner.class);
    
    private static final DocumentBuilderFactory dbuilderFactory = DocumentBuilderFactory.newInstance();
    static {
        dbuilderFactory.setNamespaceAware(true);
    }
    private DocumentBuilder dbuilder;

    private FieldSearchIterator delegate;

    private FedoraClient fedoraClient;

    private String oaiItemId;
    
    private String isMemberOfExpr;

    private Map<String, SetInfo> cachedSets = new HashMap<String, SetInfo>();
    
    private XPathUtils xpathUtils = new XPathUtils();
    
    private SetHandler setHandler;

    public FedoraSearchResultCombiner(FieldSearchIterator delegate, FedoraClient fedoraClient, String oaiItemId, SetHandler setHandler) {
        super(null, null, null);
        this.delegate = delegate;
        this.fedoraClient = fedoraClient;

        try {
            dbuilder = dbuilderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException("Cannot create W3C DocumentBuilder", e);
        }
        this.oaiItemId = oaiItemId;
        
        // TODO Use setSpecPath instead of hard coded XPath expression
        // setSpecPath is a triple pattern like $item <info:fedora/fedora-system:def/relations-external#isMemberOf> $set $set <http://www.openarchives.org/OAI/2.0/setSpec> $setSpec
        isMemberOfExpr = "//rel:isMemberOf/@rdf:resource";
        
        this.setHandler = setHandler;
    }

    @Override
    public String readLine() {
        if (!delegate.hasNext()) return null;
        ObjectFields record = delegate.next();
        return createLine(record);
    }

    /**
     * Expected format returned is:
     * "item","itemID","date","state","hasAbout"[,"setSpec1"[,"setSpec2"[,...]]]
     * For example:
     * info:fedora/nsdl:2051858,oai:nsdl.org:nsdl:10059:nsdl:2051858,2005-09-20T12:50:01,info:fedora/fedora-system:def/model#Active,true,5101,set2
     * @throws Exception 
     * @throws RemoteException 
     */
    private String createLine(ObjectFields record) {
        // Map pid to RDF format
        String pid = record.getPid();
        pid = "info:fedora/" + pid;
        
        // No mapping needed for mDate
        String mDate = record.getMDate();
        
        // Map state to the RDF format
        String state = record.getState();   // A = Active, D = Deleted
        if ("A".equals(state)) {
            state = "info:fedora/fedora-system:def/model#Active";
        } else {
            state = "info:fedora/fedora-system:def/model#Inactive";
        }
        
        String itemId = null;
        ArrayList<String> setSpecs = new ArrayList<String>();
        // Get RELS-EXT stream from Fedora to determine the item ID and set membership
        logger.debug("Getting RELS-EXT stream for document " + pid);
        MIMETypedStream stream;
        try {
            stream = fedoraClient.getAPIA().getDatastreamDissemination(pid, "RELS-EXT", "");
        } catch (Exception e) {
            throw new RepositoryException("Cannot retrieve RELS-EXT stream", e);
        }
        // Parse stream as XML
        if (dbuilder == null) {
            throw new RepositoryException("Cannot parse RELS-EXT stream because DocumentBuilder was not created");
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Got RELS-EXT stream: " + new String(stream.getStream(), Charset.forName("ASCII")));
        }
        Document document;
        try {
            document = dbuilder.parse(new ByteArrayInputStream(stream.getStream()));
        } catch (Exception e) {
            throw new RepositoryException("Cannot parse RELS-EXT stream", e);
        }
        
        Node itemIdNode = xpathUtils.evaluateRdfPropertyAsNode(oaiItemId, document);
        if (itemIdNode == null) {
            logger.warn("Object is missing itemID property.");
        } else {
            itemId = itemIdNode.getTextContent();
        }

        SetInfo setInfo;
        NodeList isMemberOf = xpathUtils.evaluateAsNodeSet(isMemberOfExpr, document);
        for (int i = 0; i < isMemberOf.getLength(); i++) {
            setInfo = getSet(isMemberOf.item(i).getTextContent().substring(12));    // strip off "info:fedora/"
            setSpecs.add(setInfo.getSetSpec());
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append(pid).append(",");  // item; = "info:fedora/" + pid
        sb.append(itemId).append(",");  // itemID; from RELS-EXT property {http://www.openarchives.org/OAI/2.0/}itemID
        sb.append(mDate).append(",");  // date; from object fields
        sb.append(state).append(",");  // state; from object fields
        sb.append(false);  // hasAbout; from ABOUT stream (using false for now)
        for (String setSpec : setSpecs) {
            sb.append(",").append(setSpec);  // setSpecs; from RELS-EXT property {info:fedora/fedora-system:def/relations-external#}isMemberOf
        }
        return sb.toString();
    }

    @Override
    public void close() {
        delegate.close();
    }
    
    /**
     * 
     * @param pid The pid without the info:fedora/ prefix
     * @return
     * @throws RepositoryException
     */
    public SetInfo getSet(String pid) throws RepositoryException {
        SetInfo setInfo;
        synchronized (cachedSets) {
            if (cachedSets.containsKey(pid)) {
                setInfo = cachedSets.get(pid);
            } else {
                setInfo = setHandler.createFedoraSetInfo(pid, null);
                cachedSets.put(pid, setInfo);
            }
        }
        return setInfo;
    }
}
