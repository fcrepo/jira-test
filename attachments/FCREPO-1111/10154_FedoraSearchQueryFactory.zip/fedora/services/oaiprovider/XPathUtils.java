package fedora.services.oaiprovider;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XPathUtils {

    private static final XPathFactory xpathFactory = XPathFactory.newInstance();
    
    private XPath xpath = xpathFactory.newXPath();

    private final Map<String, XPathExpression> compiledXpaths = new HashMap<String, XPathExpression>();
    
    public XPathUtils() {
        final Map<String, String> namespaces = new HashMap<String, String>();
        namespaces.put("oai", "http://www.openarchives.org/OAI/2.0/");
        namespaces.put("rel", "info:fedora/fedora-system:def/relations-external#");
        namespaces.put("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
        NamespaceContext nsContext = new NamespaceContext() {

            @Override
            public String getNamespaceURI(String prefix) {
                return namespaces.get(prefix);
            }

            @Override
            public String getPrefix(String namespaceURI) {
                for (Map.Entry<String, String> entry : namespaces.entrySet()) {
                    if (entry.getValue() != null && entry.getValue().equals(namespaceURI)) {
                        return entry.getKey();
                    }
                }
                return null;
            }

            @Override
            public Iterator<String> getPrefixes(String namespaceURI) {
                return namespaces.keySet().iterator();
            }
            
        };
        xpath.setNamespaceContext(nsContext);
    }

    public String getNamespacePrefix(String namespace) {
        return xpath.getNamespaceContext().getPrefix(namespace);
    }

    public String evaluateRdfPropertyAsString(String url, Node node) {
        String xpathExpr = rdfToXpath(url);
        return evaluateAsString(xpathExpr, node);
    }

    public Node evaluateRdfPropertyAsNode(String url, Node node) {
        String xpathExpr = rdfToXpath(url);
        return evaluateAsNode(xpathExpr, node);
    }

    public NodeList evaluateRdfPropertyAsNodeSet(String url, Node node) {
        String xpathExpr = rdfToXpath(url);
        return evaluateAsNodeSet(xpathExpr, node);
    }

    public String rdfToXpath(String url) {
        int p1 = url.lastIndexOf('#');
        int p2 = url.lastIndexOf('/');
        int p = Math.max(p1, p2) + 1;
        String namespace = url.substring(0, p);
        String prefix = getNamespacePrefix(namespace);
        String element = url.substring(p);
        String xpathExpr = "//" + prefix + ":" + element;
        return xpathExpr;
    }
    
    public String evaluateAsString(String expression, Node node) {
        XPathExpression xpathExpression = getXpathExpression(expression);
        try {
            return xpathExpression.evaluate(node);
        } catch (XPathExpressionException e) {
            throw new RuntimeException(e);
        }
    }
    
    public Node evaluateAsNode(String expression, Node node) {
        XPathExpression xpathExpression = getXpathExpression(expression);
        try {
            return (Node)xpathExpression.evaluate(node, XPathConstants.NODE);
        } catch (XPathExpressionException e) {
            throw new RuntimeException(e);
        }
    }
    
    public NodeList evaluateAsNodeSet(String expression, Node node) {
        XPathExpression xpathExpression = getXpathExpression(expression);
        try {
            return (NodeList)xpathExpression.evaluate(node, XPathConstants.NODESET);
        } catch (XPathExpressionException e) {
            throw new RuntimeException(e);
        }
    }
    
    private XPathExpression getXpathExpression(String expression) {
        XPathExpression result;
        synchronized(compiledXpaths) {
            if (compiledXpaths.containsKey(expression)) {
                result = compiledXpaths.get(expression);
            } else {
                result = createXpathExpression(expression);
                compiledXpaths.put(expression, result);
            }
        }
        return result;
    }
    
    private XPathExpression createXpathExpression(String expression) {
        try {
            return xpath.compile(expression);
        } catch (XPathExpressionException e) {
            throw new RuntimeException(e);
        }
    }
}
