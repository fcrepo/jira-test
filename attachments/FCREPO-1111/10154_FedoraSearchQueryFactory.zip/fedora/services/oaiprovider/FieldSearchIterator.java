package fedora.services.oaiprovider;

import java.util.NoSuchElementException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import proai.driver.RemoteIterator;
import proai.error.RepositoryException;
import fedora.client.FedoraClient;
import fedora.server.types.gen.Condition;
import fedora.server.types.gen.FieldSearchQuery;
import fedora.server.types.gen.FieldSearchResult;
import fedora.server.types.gen.ObjectFields;

public class FieldSearchIterator implements RemoteIterator<ObjectFields> {

    static final Logger logger = LoggerFactory.getLogger(FieldSearchIterator.class);
    
    private FedoraClient queryClient;
    
    private FieldSearchResult result;

    private int index;
    
    private int counter;

    private long maxResults;   // For debugging. Set to -1 for no limit.
    
    public FieldSearchIterator(Condition[] conditions, int pageSize, long maxResults, FedoraClient queryClient) {
        this.queryClient = queryClient;
        this.maxResults = maxResults;
        FieldSearchQuery query = new FieldSearchQuery(conditions, null);
        try {
            String[] resultFields = new String [] { "pid", "mDate", "state" };
            if (logger.isInfoEnabled()) {
                logger.info("Getting first page of results for {}", conditionsToString(conditions));
            }
            result = queryClient.getAPIA().findObjects(resultFields, new org.apache.axis.types.NonNegativeInteger(String.valueOf(pageSize)), query);
            if (result.getResultList().length == 0) {
                logger.info("Got no results.");
                result = null;
            } else {
                if (logger.isInfoEnabled()) {
                    if (result.getListSession() != null) {
                        logger.info("Got {} results. More results available: session token is {}.", result.getResultList().length, result.getListSession().getToken());
                    } else {
                        logger.info("Got {} results.", result.getResultList().length);
                    }
                }
            }
        } catch (Exception e) {
            throw new RepositoryException("Fedora error finding objects: " + e.getMessage(), e);
        }
    }
    
    @Override
    public void close() throws RepositoryException {
        // Nothing to close
    }

    @Override
    public boolean hasNext() throws RepositoryException {
        return result != null && (maxResults < 0 || counter < maxResults);
    }

    @Override
    public ObjectFields next() throws RepositoryException {
        if (result == null || (maxResults >= 0 && counter >= maxResults)) {
            throw new NoSuchElementException();
        }
        ObjectFields objectFields = result.getResultList()[index++];
        counter++;
        if (index >= result.getResultList().length) {
            getNextPage();
            index = 0;
        }
        logger.debug("Returning object fields: { pid = " + objectFields.getPid() + ", mDate = " + objectFields.getMDate() + ", state = " + objectFields.getState() + " }");
        return objectFields;
    }

    @Override
    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }


    public void getNextPage() throws RepositoryException {
        if (result.getListSession() == null) {    // no more results
            result = null;
            return;
        } 
        String token = result.getListSession().getToken();
        // get next page of results
        logger.info("Getting next page of results for session {}. Returned {} records so far.", token, counter);
        try {
            result = queryClient.getAPIA().resumeFindObjects(token);
        } catch (Exception e) {
            throw new RepositoryException("", e);
        }
    }

    private String conditionsToString(Condition[] conditions) {
        StringBuilder builder = new StringBuilder("[ ");
        String sep = "";
        for (int i = 0; i < conditions.length; i++) {
            builder.append(sep).append(conditions[i].getProperty()).append(' ').append(conditions[i].getOperator()).append(' ').append(conditions[i].getValue());
            sep = ", ";
        }
        builder.append(" ]");
        return builder.toString();
    }

}
