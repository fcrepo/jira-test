package fedora.services.oaiprovider;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.rmi.RemoteException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import proai.SetInfo;
import proai.error.RepositoryException;
import fedora.client.FedoraClient;
import fedora.server.types.gen.MIMETypedStream;

public class SetHandler {

    private FedoraClient fedora;

    private DocumentBuilder dbuilder;

    private String setSpec;

    private String setSpecName;

    private XPathUtils xpathUtils = new XPathUtils();
    
    public SetHandler(FedoraClient fedora, String setSpec, String setSpecName) {
        this.fedora = fedora;
        this.setSpec = setSpec;
        this.setSpecName = setSpecName;
        
        DocumentBuilderFactory dbuilderFactory = DocumentBuilderFactory.newInstance();
        dbuilderFactory.setNamespaceAware(true);
        try {
            dbuilder = dbuilderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new RepositoryException("Cannot instantiate DocumentBuilder", e);
        }
    }

    /**
     * 
     * @param pid
     *            The set object's PID, including the namespace but not the
     *            info:fedora/ prefix
     * @param setInfoDiss
     *            The dissemination string for the set info record, if any.
     * @param fedora
     *            The FedoraClient to use to retrieve the set info
     * @return
     * @throws Exception
     * @throws RemoteException
     */
    public SetInfo createFedoraSetInfo(String pid, String setInfoDisseminationType) throws RepositoryException {
        MIMETypedStream stream;
        try {
            stream = fedora.getAPIA().getDatastreamDissemination(pid, "RELS-EXT", "");
        } catch (Exception e) {
            throw new RepositoryException("Could not retrieve collection object with pid " + pid, e);
        }
        if (dbuilder == null) {
            throw new RepositoryException("Cannot parse RELS-EXT stream. DocumentBuilder was not initialized. See log file for details.");
        }

        Document document;
        try {
            document = dbuilder.parse(new ByteArrayInputStream(stream.getStream()));
        } catch (SAXException e) {
            throw new RepositoryException("Could not parse RELS-EXT stream.");
        } catch (IOException e) {
            throw new RepositoryException("Could not parse RELS-EXT stream.");
        }

        String setSpec = xpathUtils.evaluateRdfPropertyAsString(this.setSpec, document);
        String setName = xpathUtils.evaluateRdfPropertyAsString(this.setSpecName, document);
        String setDissInfo = null; // TODO: get object or call service based on PID and the setInfoSpec
        return new FedoraSetInfo(fedora, pid, setSpec, setName, setInfoDisseminationType, setDissInfo);
    }

}
