package fedora.services.oaiprovider;

import java.util.Date;

public class FedoraSearchRecord {

    private String pid;
    
    private Date mDate;
    
    private char state;

    public FedoraSearchRecord() {
        
    }
    
    public FedoraSearchRecord(String pid, Date mDate, char state) {
        this.pid = pid;
        this.mDate = mDate;
        this.state = state;
    }
    
    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public Date getmDate() {
        return mDate;
    }

    public void setmDate(Date mDate) {
        this.mDate = mDate;
    }

    public char getState() {
        return state;
    }

    public void setState(char state) {
        this.state = state;
    }
 
    
}
