
package fedora.services.oaiprovider;

import java.util.Date;
import java.util.Iterator;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;

import proai.MetadataFormat;
import proai.SetInfo;
import proai.driver.RemoteIterator;
import proai.error.RepositoryException;
import fedora.client.FedoraClient;
import fedora.common.Constants;
import fedora.server.types.gen.ComparisonOperator;
import fedora.server.types.gen.Condition;
import fedora.server.types.gen.ObjectFields;
import fedora.server.types.gen.RepositoryInfo;
import fedora.server.utilities.DateUtility;

public class FedoraSearchQueryFactory
        implements QueryFactory, Constants {

    private static final Logger logger = Logger.getLogger(FedoraOAIDriver.class.getName());

    private static final String PROP_COLL_PID_NS = FedoraOAIDriver.NS + "collectionPidNamespace";

    private static final String PROP_PID_NS = FedoraOAIDriver.NS + "pidNamespace";

    private static final String PROP_QUERY_PAGE_SIZE = FedoraOAIDriver.NS + "queryPageSize";

    private static final String PROP_QUERY_MAX_RESULTS = FedoraOAIDriver.NS + "queryMaxResults";

    private String m_oaiItemID;

    private String m_setSpec;

    private String m_setSpecName;

    private String m_itemSetSpecPath;

    private FedoraClient m_fedora;

    private FedoraClient m_queryClient;

    private String m_pidNamespace;
    
    private String m_collectionPidNamespace;

    private SetHandler setHandler;

    private int m_pageSize = 100;
    
    private long m_maxResults = -1;
    
    public FedoraSearchQueryFactory() throws ParserConfigurationException {
    }

    public void init(FedoraClient client,
                     FedoraClient queryClient,
                     Properties props) {
        m_fedora = client;
        m_queryClient = queryClient;

        RepositoryInfo repositoryInfo;
        try {
            repositoryInfo = client.getAPIA().describeRepository();
        } catch (Exception e) {
            throw new RuntimeException("Could not contact Fedora to obtain repository description");
        }

        m_oaiItemID = FedoraOAIDriver.getRequired(props, FedoraOAIDriver.PROP_ITEMID);

        m_setSpec = FedoraOAIDriver.getOptional(props, FedoraOAIDriver.PROP_SETSPEC);
        if (!m_setSpec.equals("")) {
            m_setSpecName = FedoraOAIDriver.getRequired(props, FedoraOAIDriver.PROP_SETSPEC_NAME);
            m_itemSetSpecPath = parseItemSetSpecPath(FedoraOAIDriver.getRequired(props, FedoraOAIDriver.PROP_ITEM_SETSPEC_PATH));
        }

        if (FedoraOAIDriver.getOptional(props, FedoraOAIDriver.PROP_DELETED).length() != 0) {
            logger.warn("Ignoring " + FedoraOAIDriver.PROP_DELETED + " property. Always using Fedora state to determine whether object is deleted.");
        }
        
        m_collectionPidNamespace = FedoraOAIDriver.getOptional(props, FedoraSearchQueryFactory.PROP_COLL_PID_NS);
        if (m_collectionPidNamespace.length() == 0) {
            logger.info("Using default collection namespace 'col'. Override with " + FedoraSearchQueryFactory.PROP_COLL_PID_NS + " property.");
            m_collectionPidNamespace = "col";
        }
        
        m_pidNamespace = FedoraOAIDriver.getOptional(props, FedoraSearchQueryFactory.PROP_PID_NS);
        if (m_pidNamespace.length() == 0) {
            m_pidNamespace = repositoryInfo.getRepositoryPIDNamespace();
            logger.info("Using default PID namespace '" + m_pidNamespace + " from Fedora repository description. Override with " + FedoraSearchQueryFactory.PROP_PID_NS + " property.");
            m_pidNamespace = "col";
        }

        String pageSize = FedoraOAIDriver.getOptional(props, FedoraSearchQueryFactory.PROP_QUERY_PAGE_SIZE);
        if (pageSize.length() > 0) {
            logger.info("Setting query page size to " + pageSize);
            m_pageSize = Integer.parseInt(pageSize);
        }
        String maxResults = FedoraOAIDriver.getOptional(props, FedoraSearchQueryFactory.PROP_QUERY_MAX_RESULTS);
        if (maxResults.length() > 0) {
            logger.info("Setting query result limit to " + maxResults + ". WARNING: not for production use!");
            m_maxResults = Long.parseLong(maxResults);
        }
        setHandler = new SetHandler(m_fedora, m_setSpec, m_setSpecName);
    }

    /**
     * Rather than querying for this information, which can be costly, simply
     * return the current date.
     * 
     * @param formats
     *        iterator over all FedoraMetadataFormats
     * @return current date according to Fedora
     */
    public Date latestRecordDate(Iterator<? extends MetadataFormat> formats) throws RepositoryException {
        Date current = new Date();

        logger.info("Current date reported by Fedora is " + DateUtility.convertDateToString(current));
        return current;
    }

    /**
     * Return 
     */
    public RemoteIterator<SetInfo> listSetInfo(final InvocationSpec setInfoSpec) {
        if (m_itemSetSpecPath == null) {
            // return empty iterator if sets not configured
            return new FedoraSetInfoIterator();
        } else {
            Condition[] conditions = { new Condition("pid", ComparisonOperator.has, m_collectionPidNamespace + ":*") };
            if (logger.isDebugEnabled()) {
                logger.debug("Calling Fedora::findObjects with condition pid~" + conditions[0].getValue());
            }
            final FieldSearchIterator fieldSearchIterator = new FieldSearchIterator(conditions, m_pageSize, -1, m_queryClient);
            return new RemoteIterator<SetInfo>() {

                @Override
                public void close() throws RepositoryException {
                    fieldSearchIterator.close();
                }

                @Override
                public boolean hasNext() throws RepositoryException {
                    return fieldSearchIterator.hasNext();
                }

                @Override
                public SetInfo next() throws RepositoryException {
                    ObjectFields fields = fieldSearchIterator.next();
                    String pid = fields.getPid();
                    return setHandler.createFedoraSetInfo(pid, setInfoSpec.getDisseminationType());
                }

                @Override
                public void remove() throws UnsupportedOperationException {
                    fieldSearchIterator.remove();
                }
                
            };
        }
    }

    /**
     * Convert the given Date to a String.
     */
    protected String getDateString(Date date) {
        if (date == null) {
            return null;
        } else {
            long time = date.getTime();
            return DateUtility.convertDateToString(new Date(time));
        }
    }

    public RemoteIterator<FedoraRecord> listRecords(Date from,
                                                    Date until,
                                                    FedoraMetadataFormat format) {

        // Construct and get results of one to three queries, depending on conf
        // Parse and convert the dates once; they may be used more than once
        String afterUTC = getDateString(from);
        String beforeUTC = getDateString(until);

        // do primary query
        Condition[] conditions = getListRecordsQuery(afterUTC, beforeUTC, format.getMetadataSpec());
        FieldSearchIterator fieldSearchIterator = new FieldSearchIterator(conditions, m_pageSize, m_maxResults, m_queryClient);
        
        String mdDissType = format.getMetadataSpec().getDisseminationType();
        String aboutDissType = null;
        if (format.getAboutSpec() != null) {
            aboutDissType = format.getAboutSpec().getDisseminationType();
        }
        
        // Convert to FedoraRecords
        return new CombinerRecordIterator(format.getPrefix(), mdDissType, aboutDissType, new FedoraSearchResultCombiner(fieldSearchIterator, m_fedora, m_oaiItemID, setHandler));

    }

    protected Condition[] getListRecordsQuery(String afterUTC,
                                                String beforeUTC,
                                                InvocationSpec mdSpec) {
        Condition[] conditions = { 
                new Condition("pid", ComparisonOperator.has, m_pidNamespace + ":*"), 
                new Condition("mDate", ComparisonOperator.ge, afterUTC), 
                new Condition("mDate", ComparisonOperator.le, beforeUTC) 
        };
        return conditions;
    }


    /**
     * @param itemSetSpecPath
     * @return the setSpec, in the form "$item <$predicate> $setSpec"
     * @throws RepositoryException
     */
    protected String parseItemSetSpecPath(String itemSetSpecPath)
            throws RepositoryException {
        String msg = "Required property, itemSetSpecPath, ";
        String[] path = itemSetSpecPath.split("\\s+");
        if (itemSetSpecPath.indexOf("$item") == -1) {
            throw new RepositoryException(msg + "must include \"$item\"");
        }
        if (itemSetSpecPath.indexOf("$setSpec") == -1) {
            throw new RepositoryException(msg + "must include \"$setSpec\"");
        }
        if (!itemSetSpecPath.matches("(\\$\\w+\\s+<\\S+>\\s+\\$\\w+\\s*)+")) {
            throw new RepositoryException(msg
                    + "must be of the form $item <predicate> $setSpec");
        }
        if (path.length == 3 && path[1].equals(m_setSpec)) {
            throw new RepositoryException(msg
                    + "may not use the same predicate as defined in setSpec");
        }

        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < path.length; i++) {
            if (i != 0) {
                sb.append(" ");
                if (i % 3 == 0) {
                    sb.append("and ");
                }
            }
            sb.append(path[i]);
            if (path[i].startsWith("$")
                    && !(path[i].equals("$item") || path[i].equals("$set") || path[i]
                            .equals("$setSpec"))) {
                sb.append(path[i].hashCode());
            }
        }
        return (sb.toString());
    }

}
