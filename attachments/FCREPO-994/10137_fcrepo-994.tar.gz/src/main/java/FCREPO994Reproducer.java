import java.util.LinkedList;
import java.util.Queue;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;

public class FCREPO994Reproducer {
	private static final int OBJECT_COUNT=5000; 
	private Queue<String> deleteQueue=new LinkedList<String>();
	

	public static void main(String[] args) {
		FCREPO994Reproducer re = new FCREPO994Reproducer();
		try {
			re.startIngest();
			re.startDelete();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void startDelete() {
		while (!deleteQueue.isEmpty()){
			Thread del=new Thread(new DeleteThread(deleteQueue.poll()));
			del.start();
		}
		System.out.println("delete finished");
	}

	private void startIngest() throws Exception {
		Client client=Client.create();
		client.addFilter(new HTTPBasicAuthFilter("fedoraAdmin", "fedora"));
		WebResource resource=client.resource("http://localhost:8080/fedora/objects/new?label=testobject_fcrepo994&namespace=fcrepo994");
		for (int i=0;i<OBJECT_COUNT;i++){
		ClientResponse resp=resource.post(ClientResponse.class);
			if (resp.getStatus()!=201){
				System.out.println("::" + resp.getEntity(String.class));
			}else{
				deleteQueue.add(resp.getEntity(String.class));
			}
			if (i % 100 == 0 && i > 0){
				System.out.println(i + " objects ingested");
			}
		}
		System.out.println("ingest finished");
	}


	private class DeleteThread implements Runnable {
		private final String pid;
		public DeleteThread(String pid) {
			this.pid=pid;
		}
		public void run() {
			Client client=Client.create();
			client.addFilter(new HTTPBasicAuthFilter("fedoraAdmin", "fedora"));
			WebResource resource=client.resource("http://localhost:8080/fedora/objects/" + pid);
			ClientResponse resp=resource.delete(ClientResponse.class);
			if (resp.getStatus()!=200){
				System.out.println("delete '" + pid + "': " + resp.getStatus());
			}
		}
	}
}
