This patch fixes the following bug:

https://fedora-commons.org/jira/browse/FCREPO-387

----------------------------------------------------------
 This patch should ONLY be applied to Fedora 3.0 or 3.1.
----------------------------------------------------------

Once applied, the value you specify for validationQuery
in any fedora.fcfg datastore section will be respected by
the server.

To apply the patch:

  1) Stop your Fedora server.

  2) Copy the (3) files in classes/ over the same-named files in 
     webapps/fedora/WEB-INF/classes

  3) Restart your Fedora server.

Source is included in src/ if you are building Fedora from source.
