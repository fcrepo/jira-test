This patch contains three classes that, when copied over the same-named classes 
of the Fedora 2.2.1 distribution, address the following bug:

Bug #1863382: Lockup after frequent dissemination requests
http://sourceforge.net/tracker/index.php?func=detail&aid=1863382&group_id=177054&atid=879703

To apply, make backups of the original three class files in tomcat/webapps/fedora/WEB-INF/classes, shut down Tomcat, overwrite the files with the ones in this package, then restart Tomcat.
