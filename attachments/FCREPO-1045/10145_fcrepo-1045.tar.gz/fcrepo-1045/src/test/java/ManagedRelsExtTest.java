import static com.yourmediashelf.fedora.client.FedoraClient.addDatastream;
import static com.yourmediashelf.fedora.client.FedoraClient.ingest;
import static com.yourmediashelf.fedora.client.FedoraClient.modifyDatastream;
import static com.yourmediashelf.fedora.client.FedoraClient.purgeObject;
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.yourmediashelf.fedora.client.FedoraClient;
import com.yourmediashelf.fedora.client.FedoraCredentials;
import com.yourmediashelf.fedora.client.response.AddDatastreamResponse;
import com.yourmediashelf.fedora.client.response.ModifyDatastreamResponse;

public class ManagedRelsExtTest {

	private FedoraClient fedora;
	private String pid = "test:managedRelsExt";

	@Before
	public void setUp() throws Exception {
		FedoraCredentials credentials = new FedoraCredentials(
				"http://localhost:8080/fedora", "fedoraAdmin", "fedoraAdmin");
		fedora = new FedoraClient(credentials);

		ingest(pid).execute(fedora);
	}

	@After
	public void tearDown() throws Exception {
		purgeObject(pid).execute(fedora);
	}

	@Test
	public void testModifyManagedRelsExt() throws Exception {
		String dsId = "RELS-EXT";

		AddDatastreamResponse adr = addDatastream(pid, dsId)
				.controlGroup("M")
				.content(
						"<rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">"
								+ "<rdf:Description rdf:about=\"info:fedora/"
								+ pid + "\" /></rdf:RDF>").execute(fedora);

		assertEquals(201, adr.getStatus());

		ModifyDatastreamResponse mdr = modifyDatastream(pid, dsId).dsLabel(
				"blah blah").execute(fedora);
		assertEquals(200, mdr.getStatus());
	}

}
