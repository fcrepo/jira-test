curl -v -X POST -H "Slug: projects" -H "content-type:text/turtle" http://localhost:8080/rest/turnguard-indirect --data-binary @./data/002.ttl
