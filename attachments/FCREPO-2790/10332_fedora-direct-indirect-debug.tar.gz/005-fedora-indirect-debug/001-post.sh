curl -v -X POST -H "Slug: turnguard-indirect" -H "content-type:text/turtle" http://localhost:8080/rest --data-binary @./data/001.ttl
