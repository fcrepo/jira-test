curl -v -X POST -H "Slug: project-001" -H "content-type:text/turtle" http://localhost:8080/rest/turnguard-indirect/projects --data-binary @./data/003.ttl
