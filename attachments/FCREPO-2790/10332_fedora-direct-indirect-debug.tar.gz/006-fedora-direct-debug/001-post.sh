curl -v -X POST -H "Slug: turnguard-direct" -H "content-type:text/turtle" http://localhost:8080/rest --data-binary @./data/001.ttl
