package com.github.cwilper.trippitest;

import org.trippi.RDFFormat;
import org.trippi.TripleIterator;

import java.io.ByteArrayInputStream;

public class TrippiTest {

    public static void main(String[] args) throws Exception {
        TripleIterator iter = TripleIterator.fromStream(
                new ByteArrayInputStream(new byte[0]), RDFFormat.TURTLE);
        iter.close();
    }

}
