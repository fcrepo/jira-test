This project reproduces FCREPO-946[1], showing that the cause of the 
60-second hang is in Trippi, when triples are parsed by a RIOTripleIterator.

To build it:

  mvn package

To run it:

  java -jar target/trippitest-1.0.0-SNAPSHOT-jar-with-dependencies.jar

[1] More information on FCREPO-946:
    https://jira.duraspace.org/browse/FCREPO-946
