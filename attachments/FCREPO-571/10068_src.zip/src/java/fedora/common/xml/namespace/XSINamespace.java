/*
 * -----------------------------------------------------------------------------
 *
 * <p><b>License and Copyright: </b>The contents of this file are subject to the
 * Apache License, Version 2.0 (the "License"); you may not use 
 * this file except in compliance with the License. You may obtain a copy of 
 * the License at <a href="http://www.fedora-commons.org/licenses">
 * http://www.fedora-commons.org/licenses.</a></p>
 *
 * <p>Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.</p>
 *
 * <p>The entire file consists of original code.</p>
 * <p>Copyright &copy; 2008 Fedora Commons, Inc.<br />
 * <p>Copyright &copy; 2002-2007 The Rector and Visitors of the University of 
 * Virginia and Cornell University<br /> 
 * All rights reserved.</p>
 *
 * -----------------------------------------------------------------------------
 */

/* The contents of this file are subject to the license and copyright terms
 * detailed in the license directory at the root of the source tree (also 
 * available online at http://fedora-commons.org/license/).
 */

package fedora.common.xml.namespace;

/**
 * The XML Schema Instance XML namespace.
 * 
 * <pre>
 * Namespace URI    : http://www.w3.org/2001/XMLSchema-instance
 * Preferred Prefix : xsi
 * </pre>
 * 
 * @author Chris Wilper
 */
public class XSINamespace
        extends XMLNamespace {

    //---
    // Attributes
    //---

    /** The <code>schemaLocation</code> attribute. */
    public final QName SCHEMA_LOCATION;

    //---
    // Singleton instantiation
    //---

    /** The only instance of this class. */
    private static final XSINamespace ONLY_INSTANCE = new XSINamespace();

    /**
     * Constructs the instance.
     */
    private XSINamespace() {
        super("http://www.w3.org/2001/XMLSchema-instance", "xsi");

        // attributes
        SCHEMA_LOCATION = new QName(this, "schemaLocation");
    }

    /**
     * Gets the only instance of this class.
     * 
     * @return the instance.
     */
    public static XSINamespace getInstance() {
        return ONLY_INSTANCE;
    }

}
