package fedora.server.customdb;

import java.util.Iterator;
import java.util.List;

import fedora.server.errors.InconsistentTableSpecException;
import fedora.server.utilities.ColumnSpec;
import fedora.server.utilities.TableSpec;

/**
 * TableSpec with extra attributes used for custom database function.
 *
 * @author lobo
 * @version 1
 */
public class CustomTableSpec
        extends TableSpec {

    public  final static String PID_COLUMN_ID = "pid";

    private List<String> m_contentModels = null;

    private String m_datastreamId = null;

    public CustomTableSpec(String name,
                           List<ColumnSpec> columnSpecs,
                           String primaryColumnName,
                           String type,
                           List<String> contentModels,
                           String datastreamId)
            throws InconsistentTableSpecException {
        super(name, columnSpecs, primaryColumnName, type);

        m_datastreamId = datastreamId;
        m_contentModels = contentModels;
    }

    public String getDatastreamId() {
        return m_datastreamId;
    }

    public List<String> getContentModels() {
        return m_contentModels;
    }

    public boolean hasPidColumn() {
        Iterator<ColumnSpec > it = columnSpecIterator();
        while(it.hasNext()) {
            ColumnSpec column = it.next();
            if (column.getName().equals(PID_COLUMN_ID))
                return true;
        }
        return false;
    }
}
