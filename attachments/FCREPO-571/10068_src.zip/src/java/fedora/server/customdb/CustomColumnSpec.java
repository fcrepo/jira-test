package fedora.server.customdb;

import fedora.server.utilities.ColumnSpec;


/**
 * ColumnSpec with extra attributes used for custom database function.
 *
 * @author lobo
 * @version 1
 */
public class CustomColumnSpec
        extends ColumnSpec {

    private final CustomColumnValue m_columnValue;

    public CustomColumnSpec(String name,
                            String type,
                            boolean binary,
                            String defaultValue,
                            boolean isAutoIncremented,
                            String indexName,
                            boolean isUnique,
                            boolean isNotNull,
                            String foreignTableName,
                            String foreignColumnName,
                            String onDeleteAction,
                            CustomColumnValue columnValue) {
        super(name,
              type,
              binary,
              defaultValue,
              isAutoIncremented,
              indexName,
              isUnique,
              isNotNull,
              foreignTableName,
              foreignColumnName,
              onDeleteAction);
        m_columnValue = columnValue;
    }

    public CustomColumnValue getColumnValue() {
        return m_columnValue;
    }


}
