package fedora.server.customdb;

import java.util.List;

import org.dom4j.Document;


/**
 * This interface has been made with the specific purpose in mind
 * that different kind of value getters may be added later and it
 * can even be made possible to create ColumnValueGetters that
 * aggregate other ColumnValueGetters.
 *
 * @author lobo
 * @version 1
 */
public interface ColumnValueGetter {

    public DbDelimiter getDelimiter();

    /**
     * Returns all values gotten. Does not use the delimiter; that is up
     * to the user of this class.
     * @param xmlDom an XML dom4j document
     * @return retrieved values
     * @throws ColumnValueGetterException
     */
    public List<String> getValues(Document xmlDom) throws ColumnValueGetterException;

}
