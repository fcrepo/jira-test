package fedora.server.customdb;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import org.dom4j.Document;


/**
 * Container class for column value getters. This class has a DbDelimiter, just like the
 * getters. If one of the child getters has a row based delimiter this object will
 * inherit that delimiter type.
 *
 * @author lobo
 * @version 1
 */
public class CustomColumnValue {

    /** Logger for this class. */
    private static final Logger LOG = Logger.getLogger(
        CustomColumnValue.class.getName());

    private final List<ColumnValueGetter> m_columnValueGetters;

    private final DbDelimiter m_delimiter;

    public CustomColumnValue(List<ColumnValueGetter> columnValueGetters, DbDelimiter delimiter) {
        m_columnValueGetters = columnValueGetters;
        m_delimiter = delimiter;

        // inherit delimiter type row if one of the getters have the delimiter type row
        if (gettersHaveDelimitType(DbDelimiterType.ROW))
            m_delimiter.setDelimiterType(DbDelimiterType.ROW);
    }

    public void inihertDelimiterType() {
        Iterator<ColumnValueGetter> i = m_columnValueGetters.iterator();
        while(i.hasNext()) {
        }
    }

    public List<ColumnValueGetter> getColumnValueGetters() {
        return m_columnValueGetters;
    }

    /**
     * This method returns the values for this column that need to be put
     * into the database. If several values are returned this means several
     * rows need to be created. A single value may be concatenated and
     * delimited, but represents nevertheless a single row.
     * @param xmlDom the xml document to get the values from
     * @return the values that need to be put into database, each one corresponding
     * to one row.
     */
    public List<String> getDbValues(Document xmlDom) throws ColumnValueGetterException {
        // get all values and delimit them
        LOG.debug("Start get values");

        Iterator<ColumnValueGetter> i = m_columnValueGetters.iterator();
        List<String> delimitedValues = new ArrayList<String>();
        while(i.hasNext()) {
            ColumnValueGetter valueGetter = i.next();

            List<String> values = valueGetter.getValues(xmlDom);
            if (values.size() == 0)
                continue;

            DbDelimiter.delimit(values, delimitedValues, valueGetter.getDelimiter());
        }

        LOG.debug("End get values");

        // delimit the delimited values and return
        List<String> result = new ArrayList<String>();
        DbDelimiter.delimit(delimitedValues, result, getDelimiter());

        return result;
    }

    private Boolean gettersHaveDelimitType(DbDelimiterType delimitType) {
        Iterator<ColumnValueGetter> i = m_columnValueGetters.iterator();
        while(i.hasNext()) {
            ColumnValueGetter valueGetter = i.next();
            if (valueGetter.getDelimiter().getDelimiterType().equals(delimitType))
                return true;
        }
        return false;
    }

    public DbDelimiter getDelimiter() {
        return m_delimiter;
    }

}
