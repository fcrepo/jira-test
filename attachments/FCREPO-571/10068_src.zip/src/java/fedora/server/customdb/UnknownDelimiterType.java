package fedora.server.customdb;


/**
 * Thrown when an unknown database delimiter type has been entered
 *
 * @author lobo
 * @version 1
 */
public class UnknownDelimiterType
        extends ColumnValueGetterException {

    private static final long serialVersionUID = -3528197103844725240L;

    public UnknownDelimiterType(String message) {
        super(message);
    }

}
