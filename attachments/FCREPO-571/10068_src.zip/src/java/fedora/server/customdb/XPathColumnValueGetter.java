package fedora.server.customdb;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import org.dom4j.Document;
import org.dom4j.Node;

import org.jaxen.JaxenException;
import org.jaxen.dom4j.Dom4jXPath;

/**
 * Gets a value from an XML document by an xPath query
 *
 * @author lobo
 * @version 1
 */
public class XPathColumnValueGetter
        implements ColumnValueGetter {

    /** Logger for this class. */
    private static final Logger LOG = Logger.getLogger(
        XPathColumnValueGetter.class.getName());

    private String m_xPath;

    private String m_nsUri;

    private String m_nsPrefix;

    private DbDelimiter m_delimiter;

    public XPathColumnValueGetter() {
    }

    public XPathColumnValueGetter(String xPath,
                                  String nsPrefix,
                                  String nsUri,
                                  DbDelimiter delimiter) {
        m_xPath = xPath;
        m_nsPrefix = nsPrefix;
        m_nsUri = nsUri;
        m_delimiter = delimiter;
    }

    public DbDelimiter getDelimiter() {
        return m_delimiter;
    }

    public String getXPath() {
        return m_xPath;
    }

    public String getNsUri() {
        return m_nsUri;
    }

    public String getNsPrefix() {
        return m_nsPrefix;
    }

    @SuppressWarnings("unchecked")
    public List<String> getValues(Document xmlDom) throws ColumnValueGetterException {
        List<String> result = new ArrayList<String>();

        LOG.debug("Getting value by xPath expression \""+ getXPath() +
            "\" with nsUri \""+ getNsUri() +"\" and nsPrefix \""+ getNsPrefix() +"\"");

        Dom4jXPath xpath;
        try {
            xpath = new Dom4jXPath(getXPath());
            if (getNsPrefix() != null && getNsUri() != null)
                xpath.addNamespace(getNsPrefix(), getNsUri());
            List<Node> l = xpath.selectNodes(xmlDom);

            if (l.size() <= 0)
                return result;

            for (Iterator<Node> it = l.iterator(); it.hasNext();) {
                String val = it.next().getText();
                LOG.debug("Gotten value ="+ val);
                result.add( val );
            }
        } catch (JaxenException e) {
            throw new ColumnValueGetterException(
                "Error occured while getting value with xPath expression "+ m_xPath,
                e
            );
        }

        return result;
    }
}
