package fedora.server.customdb;


/**
 * If a value getter gets more than one value from the digital object
 * one may choose how one wants to store these values.
 *
 * @author lobo
 * @version 1
 */
public enum DbDelimiterType {

    /**
     * String separated delimiter
     */
    NORMAL,

    /**
     * Database row separation
     */
    ROW

}
