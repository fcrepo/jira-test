package fedora.server.customdb;

import fedora.server.errors.ServerException;

/**
 * A universal error thrown when a ColumnValueGetter runs into problems.
 *
 * @author lobo
 * @version 1
 */
public class ColumnValueGetterException
        extends ServerException {

    private static final long serialVersionUID = 1201603708210402688L;

    public ColumnValueGetterException(String message) {
        super(null, message, null, null, null);
    }

    public ColumnValueGetterException(String message, Throwable cause) {
        super(null, message, null, null, cause);
    }

    public ColumnValueGetterException(String bundleName,
                                      String code,
                                      String[] values,
                                      String[] details,
                                      Throwable cause) {
        super(bundleName, code, values, details, cause);
    }

}
