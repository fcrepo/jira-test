package fedora.server.customdb;

import java.io.IOException;
import java.io.InputStream;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;

import fedora.common.Constants;

import fedora.server.errors.ServerException;
import fedora.server.errors.StorageDeviceException;
import fedora.server.errors.StreamIOException;
import fedora.server.storage.ConnectionPool;
import fedora.server.storage.DOReader;
import fedora.server.storage.types.Datastream;
import fedora.server.storage.types.DatastreamXMLMetadata;
import fedora.server.storage.types.RelationshipTuple;
import fedora.server.utilities.ColumnSpec;
import fedora.server.utilities.SQLUtility;
import fedora.server.utilities.TableSpec;

/**
 * This class keeps the database synchronized with the digital objects that are
 * put into, and maintained, in Fedora.
 * @author lobo
 * @version 1
 */
public class CustomFieldsSQL  {

    /** Logger for this class. */
    private static final Logger LOG = Logger.getLogger(
    		CustomFieldsSQL.class.getName());

    private List<CustomTableSpec> m_customTableSpecs = null;

    private final ConnectionPool m_cPool;

    /** prefixes of numeric types in lowercase */
    public static String[] DB_NUMERIC_TYPES = new String[] { "bigint",
    	"smallint", "int", "decimal", "numeric", "real", "double",
    	"serial", "bigserial" };


    public CustomFieldsSQL(ConnectionPool cPool) {
    	this.m_cPool = cPool;
    }

    /**
     * This is the main function that provides the database with all the custom
     * values gotten from custom-db.xml (or one of the included database descriptions
     * in custom-db.xml). The ColumnValueGetters are responsible for getting the values.
     * This method tries to be as forgiving as possible.
     * @param reader the digital object reader containing the digital object
     * @throws ServerException Might be thrown when a ColumnValueGetter runs into trouble.
     * @throws SQLException only can be expected when the custom-db.xml contains different
     * table data then the database contains.
     */
    public void updateObject(DOReader reader) throws ServerException, SQLException {

	    List<CustomTableSpec> customTableSpecs = getCustomTableSpecs();
		String pid = reader.GetObjectPID();
		Connection conn = null;
		DODomPool domPool = new DODomPool();

		try
		{
    		// iterate through all custom tables, checking if it needs to be used with
    		// this object according to its content model
            for(CustomTableSpec table : customTableSpecs) {
                if (table.getContentModels() != null && !hasContentModel(reader, table.getContentModels())) {
                    continue;
                }

                LOG.debug("Initializing custom value getting for custom table "+ table.getName());


                Document xmlDom = domPool.getDocument(table.getDatastreamId());
                if (xmlDom == null) {
                    InputStream xmlIn = null;
                    if (table.getDatastreamId() != null) {
                    	// get the right datastream from the object
                    	Datastream ds = reader.GetDatastream(table.getDatastreamId(), null);
                        if (ds == null) {
                            LOG.warn("Custom field updater could not find datastream with id "+ table.getDatastreamId());
                            continue; // forgive user for not providing the datastream
                        }
                    	if (!(ds instanceof DatastreamXMLMetadata)) {
                            LOG.warn("Custom field updater found datastream with id "+ table.getDatastreamId() +
                                     " yet it is not an inline XML datastream and it needs to be.");
                    	    continue; // forgive user for not providing the right kind of datastream
                    	}
                        DatastreamXMLMetadata dsXML = (DatastreamXMLMetadata) ds;
                        xmlIn = dsXML.getContentStream();
                    }
                    else {
                        xmlIn = reader.GetObjectXML();
                    }


                    LOG.debug(
                        "Parsing "+
                        (table.getDatastreamId() == null ? " digital object " :table.getDatastreamId() + " datastream") +
                        " XML of object with pid "+ pid);

        			// parse XML
        	        SAXReader saxReader = new SAXReader();
                    try {
                        xmlDom = saxReader.read(xmlIn);
                    } catch (DocumentException e) {
                        LOG.warn("An error occured while parsing the datastream with id "+ table.getDatastreamId());
                        continue; // forgive user for not providing valid XML - should not happen anyway
                    }

                    domPool.setDocument(table.getDatastreamId(), xmlDom);
                }

            	// get the column values from the datastream
            	DbValues values = new DbValues();

                // enter hardcoded columns values
                if (table.hasPidColumn()) {
                    values.add(CustomTableSpec.PID_COLUMN_ID, pid, false );
                }

                // get softcoded columns values
            	Iterator<ColumnSpec> columnIt = table.columnSpecIterator();
            	Boolean canHaveMultipleRows = false;
    			while(columnIt.hasNext()) {
    			    ColumnSpec column = columnIt.next();
    			    if (column instanceof CustomColumnSpec) {
    			        CustomColumnSpec customColumn = (CustomColumnSpec) column;

    			        canHaveMultipleRows =
    			            customColumn.getColumnValue().getDelimiter().getDelimiterType().equals(DbDelimiterType.ROW) |
    			            canHaveMultipleRows;

    			        List<String> columnDbValues = customColumn.getColumnValue().getDbValues(xmlDom);
                        if (columnDbValues.size() > 0)
                            values.add(column.getName(), columnDbValues, isTypeNumeric(column.getType()) );
                        else if (column.getDefaultValue() != null)
                            values.add(column.getName(), column.getDefaultValue(), isTypeNumeric(column.getType()) );
                        else
                            LOG.warn("Could not find value for column "+ table.getName() +"."+ column.getName());
    				}
    			}

    	        // fill the database table with the gotten values
                if (conn == null)
                    conn = m_cPool.getConnection();



                LOG.debug("Now writing values for custom table "+ table.getName());
    	        if (!canHaveMultipleRows && table.hasPidColumn()) {
        	        SQLUtility.replaceInto(conn,
        	                               table.getName(),
        	                               values.getColumns(0),
        	                               values.getValues(0),
        	                               CustomTableSpec.PID_COLUMN_ID,
        	                               values.getNumeric(0)
        	                               );
    	        } else {
    	            deleteTableDataByPid(pid, table, conn);
    	            for (int i = 0; i < values.numRows; i++) {
                        SQLUtility.addRow(
                            conn,
                            table.getName(),
                            values.getColumns(i),
                            values.getValues(i),
                            values.getNumeric(i)
                            );
    	            }
                    LOG.debug("I");
    	        }
            }
		}
		finally
		{
		    if (conn != null)
		    {
		        m_cPool.free(conn);
		        conn = null;
		    }
		}
	}

	/**
	 * Returns true if the digital object contained in the reader contains one of the
	 * content models in the contentModels list
	 */
    private boolean hasContentModel(DOReader reader, List<String> contentModels) throws ServerException {
        Set<RelationshipTuple> cmRels = reader.getRelationships(Constants.MODEL.HAS_MODEL, null);
        for (RelationshipTuple element : cmRels) {
            for(String contentModel : contentModels) {
                if (element.object.equals(contentModel))
                    return true;
            }
        }

        return false;
	}

	public List<CustomTableSpec> getCustomTableSpecs() throws ServerException {
	    if (m_customTableSpecs == null) {

	        LOG.debug("Getting custom tables from dbspec file");

	        m_customTableSpecs = new ArrayList<CustomTableSpec>();

            // read tablespecs file
            String dbSpecLocation =
                "fedora/server/storage/resources/DefaultDOManager.dbspec";
            InputStream in = getClass().getClassLoader().getResourceAsStream(dbSpecLocation);
            List<TableSpec> tableSpecs;
            try {
                tableSpecs = TableSpec.getTableSpecs(in);
            }
            catch(IOException e) {
                throw new StreamIOException( "Error while reading dbspec file: "+ dbSpecLocation, e);
            }

            // filter out custom table specs
	        for(TableSpec tableObj : tableSpecs) {
                if (!(tableObj instanceof CustomTableSpec))
                    continue;
                m_customTableSpecs.add((CustomTableSpec) tableObj);
            }

           LOG.debug("Found "+ m_customTableSpecs.size() +" custom tables.");
	    }

        return m_customTableSpecs;
	}

	protected boolean isTypeNumeric(String type) {
		type = type.toLowerCase();
		for (int i = 0; i < DB_NUMERIC_TYPES.length; i++) {
			if ( type.startsWith(DB_NUMERIC_TYPES[i]))
				return true;
		}
		return false;
	}

	/**
	 * Deletes one or more rows of the custom tables by their pids. Called when
	 * a digital object gets purged from Fedora.
	 */
	public boolean delete(String pid) throws ServerException {
        Connection conn = null;
        try {

            conn = m_cPool.getConnection();
            List<CustomTableSpec> tables = getCustomTableSpecs();
            for (CustomTableSpec table : tables) {
                deleteTableDataByPid(pid, table, conn);
            }
            return true;

        } catch (SQLException sqle) {
            throw new StorageDeviceException("Error attempting delete of "
                    + "object with pid '" + pid + "': " + sqle.getMessage());
        } finally {
            if (conn != null) {
                m_cPool.free(conn);
            }
        }
    }

    private boolean deleteTableDataByPid(String pid, CustomTableSpec table, Connection conn) throws ServerException, SQLException {
        if (!table.hasPidColumn())
            return false;

        Statement st = null;
        try {

            st = conn.createStatement();
            st.executeUpdate("DELETE FROM "+ table.getName() +" WHERE "+
                CustomTableSpec.PID_COLUMN_ID +"='" + pid + "'");

            return true;
        }
        finally {
            if (st != null) {
                st.close();
            }
        }
    }

    /**
     * Small private helper class to store database values. Stores
     * column values. If there are multiple columns values for the
     * same column, it helps break them up in rows.
     */
    private class DbValues {

        public ArrayList<DbValue> values = new ArrayList<DbValue>();
        public int numRows = 0;

        public void add(String column, String value, Boolean isNumeric) {
            values.add( new DbValue(column, value, isNumeric ) );
            numRows = Math.max(numRows, 1);
        }

        public void add(String column, List<String> pValues, Boolean isNumeric) {
            values.add( new DbValue(column, pValues, isNumeric ) );
            numRows = Math.max(numRows, pValues.size());
        }

        public int getNumRows() {
            return numRows;
        }

        public String[] getColumns(int row) {
            String[] result = new String[ values.size() ];
            for (int i = 0; i < values.size(); i++) {
                result[i] = values.get(i).name;
            }
            return result;
        }

        public String[] getValues(int row) {
            String[] result = new String[ values.size() ];
            for (int i = 0; i < values.size(); i++) {
                List<String> v = values.get(i).values;
                result[i] = v.get( Math.min(v.size()-1, row) );
            }
            return result;
        }

        public boolean[] getNumeric(int row) {
            boolean[] result = new boolean[ values.size() ];
            for (int i = 0; i < values.size(); i++) {
                result[i] = values.get(i).numeric;
            }
            return result;
        }

        private class DbValue {

            public Boolean      numeric;
            public String       name;
            public List<String> values;

            public DbValue(String pname, String pvalue, Boolean pnumeric) {
                name = pname;
                values = new ArrayList<String>(1);
                values.add(pvalue);
                numeric = pnumeric;
            }

            public DbValue(String pname, List<String> pvalues, Boolean pnumeric) {
                name = pname;
                values = pvalues;
                numeric = pnumeric;
            }

        }
    }

    /**
     * A simple object that is used for caching xml document objects
     * based on the datastreamId (which might also be null).
     */
    private class DODomPool {

        private final List<DODom> pool = new ArrayList<DODom>();

        public Document getDocument(String datastreamId) {
            for (DODom obj : pool) {
                if ((datastreamId == null && obj.datastreamId == null) ||
                    (obj.datastreamId.equals(datastreamId))) {
                    return obj.dom;
                }
            }
            return null;
        }

        public void setDocument(String datastreamId, Document dom) {
            DODom obj = new DODom();
            obj.datastreamId = datastreamId;
            obj.dom = dom;
            pool.add(obj);
        }

        private class DODom {
            public String datastreamId;
            public Document dom;
        }

    }
}

