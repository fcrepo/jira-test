package fedora.server.customdb;

import java.util.Iterator;
import java.util.List;


/**
 * If a value getter gets more than one value from the digital object
 * one may choose how one wants to store these values. By default
 * one row is made and the values are separated by commas.
 *
 * @author lobo
 * @version 1
 */
public class DbDelimiter {

    private DbDelimiterType delimiterType = DbDelimiterType.NORMAL;

    private String delimiterValue = ",";

    public void setDelimiterType(DbDelimiterType delimiterType) {
        this.delimiterType = delimiterType;
    }

    public DbDelimiterType getDelimiterType() {
        return delimiterType;
    }

    public void setDelimiterValue(String delimiterValue) {
        this.delimiterValue = delimiterValue;
    }

    public String getDelimiterValue() {
        return delimiterValue;
    }

    public static void delimit(List<String> in, List<String> out, DbDelimiter delimiter) throws ColumnValueGetterException {
        if (in.size() == 0)
            return;

        switch(delimiter.getDelimiterType()) {

            case ROW: {
                out.addAll( in );
                break;
            }

            case NORMAL: {
                String value = "";
                Iterator<String> j = in.iterator();
                while(j.hasNext()) {
                    value += j.next();
                    if (j.hasNext()) {
                        value += delimiter.getDelimiterValue();
                    }
                }
                out.add(value);
                break;
            }

            default:
                throw new ColumnValueGetterException("Unknown delimiter type");
        }

    }


}
